
const config = {
  consumer_key: 'HAYeSuble5D2ZMr5EH67x2lZY',
  consumer_secret: 'ynrM8UfVKbvmulDtpiV1s0EHQx9r84QvhZQb2UbVBFZOhr2dvG',
  access_token: '1046941689200267264-JPMwUuHs0QW4E3P0EqWQn7pwX3yCUJ',
  access_token_secret: '7jW3GM7e33aIHMTbKqhcKdT6xpGk2SO1SguppGeYweQs0'
}

module.exports = config;